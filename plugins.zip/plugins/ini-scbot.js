/* 
* Mau Ngapain ?
* Mau Ubah ?
* Humm Boleh
* Awas Ajh Kalo Gada Nama Gw 
* Arifzyn
* No Enc ? wa.me/62895347198105
* Ngapain beli 🗿
*/


import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
let handler = async (m, { conn, text, usedPrefix, command }) => {
return conn.sendButton(m.chat, htki + ' ' + author + ' ' + htka, `${htjava}\n${dmenub} ${conn.user.name} Source Code:\n${dmenub} ${sgh}\n${dmenuf}`, logo, [['Owner', '/owner'], ['Donasi', '/donasi']], fakes, adReply)
SC By : arifzyn
Recode By : ZansLord

Mo sc? donasi dulu ngentot🗿

}

handler.command = /^sc(ript(bot)?|bot)?$/i
export default handler
